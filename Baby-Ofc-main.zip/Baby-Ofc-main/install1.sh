apt-get install nodejs -y
apt-get install ffmpeg libwebp -y
apt-get install wget -y
apt-get install imagemagick -y
apt-get install tesseract -y
npm i node-tesseract-ocr
npm i @adiwajshing/baileys@3.4.1
pkg install termimage
pkg install toilet
pkg install cowsay
pkg install neofetch
npm i ffmpeg
npm i cfonts
npm install
npm i yt-search
npm i google-it
npm i g-i-s
npm i hxz-api
npm i
echo -e '\e[1;32m
Descarga Completada al 100%
Creador: Thechoute
Numero: +18299897014
Instagram: the_choute_
Youtube: https://www.youtube.com/c/thechout
Escribe node thechoute para iniciar el bot
En caso que el bot presente algun problema, comunicate con el creador su numero esta mas arriba
'
