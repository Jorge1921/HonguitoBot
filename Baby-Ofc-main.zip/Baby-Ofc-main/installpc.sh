echo -e '\e[1;32m
▀█▀ █▀▀▄ █▀▀ ▀▀█▀▀ █▀▀█ █── █▀▀█ █▀▀▄ █▀▀▄ █▀▀█ 　 ░█▀▄▀█ █▀▀█ █▀▀▄ █──█ █── █▀▀█ █▀▀ 
░█─ █──█ ▀▀█ ──█── █▄▄█ █── █▄▄█ █──█ █──█ █──█ 　 ░█░█░█ █──█ █──█ █──█ █── █──█ ▀▀█ 
▄█▄ ▀──▀ ▀▀▀ ──▀── ▀──▀ ▀▀▀ ▀──▀ ▀──▀ ▀▀▀─ ▀▀▀▀ 　 ░█──░█ ▀▀▀▀ ▀▀▀─ ─▀▀▀ ▀▀▀ ▀▀▀▀ ▀▀▀ 
░█▄─░█ █▀▀ █▀▀ █▀▀ █▀▀ █▀▀█ █▀▀█ ─▀─ █▀▀█ █▀▀ 
░█░█░█ █▀▀ █── █▀▀ ▀▀█ █▄▄█ █▄▄▀ ▀█▀ █──█ ▀▀█ 
░█──▀█ ▀▀▀ ▀▀▀ ▀▀▀ ▀▀▀ ▀──▀ ▀─▀▀ ▀▀▀ ▀▀▀▀ ▀▀▀'

npm install
npm i ffmpeg
npm i cfonts
npm i yt-search
npm i google-it
npm i g-i-s
npm i hxz-api
npm i node-fetch
npm i moment-timezone
npm i child_process
npm i fluent-ffmpeg
npm i 

echo -e '\e[1;32m
Descarga Completada al 100%
En caso que presente algun error al iniciar escribe
npm i
Creador: Thechoute
Numero: +18299897014
Instagram: the_choute_
Youtube: https://www.youtube.com/c/thechout
Escribe node thechoute para iniciar el bot
En caso que el bot presente algun problema, comunicate con el creador su numero esta mas arriba'
