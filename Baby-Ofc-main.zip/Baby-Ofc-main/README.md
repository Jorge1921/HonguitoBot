<p align="center">
<img src="./media/pornhub.jpg" width="140" height="140"/>
<p align="center">

<p align="center">
<a href="https://github.com/thechoute/"><img title="Author" src="https://img.shields.io/badge/Author-𝕿𝖍ٌ𝖊𝕮𝖍𝖔𝖚𝖙𝖊-red.svg?style=for-the-badge&logo=github"></a>

<p align="center">

<p align="center">
<a href="http://wa.me/18299897014" target="blank"><img src="https://img.shields.io/badge/Whatsapp-30302f?style=flat&logo=whatsapp" /></a>
<a href="http://www.instagram.com/the_choute_" target="blank"><img src="https://img.shields.io/badge/Instagram-30302f?style=flat&logo=instagram" /></a>
<a href="https://www.youtube.com/channel/UC-HPutaDGeTPjrCId0bXQgg" target="blank"><img src="https://img.shields.io/badge/Youtube-30302f?style=flat&logo=youtube" /></a>
<p align="center">
</p>

### PROCESO DE INSTALACION
Instala los archivos necesarios
```bash
- termux-setup-storage
- pkg upgrade && update
- pkg install nodejs
- pkg install git
- pkg install bash
```

Clona este repositorio
 ```bash
> git clone https://github.com/thechoute/Baby-Ofc
```

Inicia la instalacion
```bash
- cd Baby-Ofc
- bash install.sh
```
Nota: Si la instalacion sera en Pc, utiliza
```bash
- bash installpc.sh
```

Para Iniciar el Bot
 ```bash
- node thechoute
```
### PARA WINDOWS/VPS/RDP USER💻

- Pulsa Para Instalar Git [`Click Here`](https://git-scm.com/downloads) <br>
- Pulsa Para Instalar NodeJS [`Click Here`](https://nodejs.org/en/download) <br>
- Pulsa Para Instalar FFMPEG [`Click Here`](https://ffmpeg.org/download.html) 
- Pulsa Para Instalar ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)
